package com.coin.coin;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.coin.coin.entity.Member;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class Mapper {
	
	@Autowired
	com.coin.coin.mapper.JoinMapper mapper;
	
	@Test@Ignore
	public void test() {
		Member m = new Member();
		
		m.setId("test2");
		m.setPassword("p2");
		m.setEmail("email2");
		m.setNickname("nick2");
		m.setHobby("h2");
		m.setInterest("in2");
		m.setSeed("seed2s");
		
		mapper.memberJoin(m);
	}
	@Test@Ignore
	public void test2() {
		Member member1 = new Member();
		
		member1.setId("idid11");
		member1.setPassword("password123");
		
		mapper.memberlogin(member1);
		System.out.println(mapper.memberlogin(member1));
	}
	
//	@Test
//	public void test3() {
//		Member mem1 = new Member();
//		
//		mem1.setId("mapping578");
//		mem1.setPassword("mapping1234");
//		mem1.setEmail("email@email.com");
//		mem1.setNickname("slkfjwhqrq");
//		mapper.memberJoin(mem1);
//		
//		Member mem2 = new Member();
//		mem2.setId(mem1.getId());
//		mem2.setPassword("mapping1");
//		mem2.setEmail("email12@email.com");
//		mem2.setNickname("slkfjwh145");
//		int cnt = mapper.memberupdate(mem2);
//		
//		assertEquals(cnt, 1);
//		System.out.println(cnt);
//		
//	}

}
