package com.coin.coin.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coin.coin.HomeController;
import com.coin.coin.entity.Member;
import com.coin.coin.service.JoinService;

@Controller
@RequestMapping("coin")
public class JoinController {
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	JoinService service;
	
	@GetMapping("join")
	public String joinform() {
		return "joinform";
	}
	@ResponseBody
	@PostMapping("idcheck")
	public int idcheck(String id) {
		int result = service.idcheck(id);
		return result;
	}
	@ResponseBody
	@PostMapping("emailcheck")
	public int emailcheck(String email) {
		int result = service.emailcheck(email);
		return result;
	}
	
	@PostMapping("join")
	public String join(Member member) {
		
		service.memberJoin(member);
		
		return "loginform";
	}
	
	@GetMapping("findid")
	public String findidform() {
		return "findid1";
	}
	
	@PostMapping("findid")
	public String findid(String email, Model model) {
		Member member2 = service.findId(email);
		
		model.addAttribute("member2", member2);
		
		return "findid2";						
	}
	
	@GetMapping("login")
	public String login() {
		return "loginform";
	}
	
	@PostMapping("login")
	public String login2(HttpServletRequest re, Member member,Model model) {
		
		HttpSession session = re.getSession();
		
		Member member3 = service.memberlogin(member);
		
		if(member3 == null) {
			int num = 0; 
			
			model.addAttribute("result", num);
			return "loginform";
		}
		
		session.setAttribute("member", member3);
		
		return "main";
	}
	
	@GetMapping("logout")
	public String logout(HttpServletRequest re) {
		HttpSession session = re.getSession();
		
		session.invalidate();
		
		return "main";
	}
	
	@RequestMapping("main")
	public String main() {
		return "main";
	}
	
	//mypage
	@RequestMapping("mypage")
	public String mypage1(Model model) {
		
		return "mypage1";
	}
	
	//update
	@GetMapping("update")
	public String updatepage(String id, Model model) {
		
		Member member1 = service.findId(id);
		model.addAttribute("member",member1);
		
		return "mypage2";
	}
	
	@PostMapping("update")
	public String update(Member member,Model model) {

		String result = service.memberupdate(member);
		
		model.addAttribute("result", result);
		
		return "mypage3";
	}
	
	//delete
	@GetMapping("delete")
	public String delete() {
		return "delete";
	}
	
	@PostMapping("delete")
	public String delete2(String id, String password,Model model, HttpServletRequest re) {
		int a = service.deletemember(id, password);
		model.addAttribute("a", a);
//		if(a != 1) {
//			return "deleteresult";
//			
//		}
//		return "main";
		HttpSession session = re.getSession();
		
		session.invalidate();
		return "deleteresult";
	}
}
