package com.coin.coin.dao;

import com.coin.coin.entity.Member;

public interface JoinDao {
	
//	public void memberJoin(Member member);
	
	public int memberupdate(Member member);
}
