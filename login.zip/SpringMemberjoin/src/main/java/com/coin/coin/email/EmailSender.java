package com.coin.coin.email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;

public class EmailSender {
	
	@Autowired
	private JavaMailSender mailSender;

	       


	
	

	
}
