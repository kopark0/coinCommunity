package com.coin.coin.mapper;


import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.coin.coin.entity.Member;

@Mapper
public interface JoinMapper {
	//회원가입
	public void memberJoin(Member member);
	//아이디 찾기
	public Member findId(String email);
	//로그인하기
	public Member memberlogin(Member member);
	//전체 정보 조회
	public Member selectall(String id);
	//수정
	public int memberupdate(Member member);
	//delete
	public int memberdelete(@Param("id") String id, @Param("password")String password);
	
	//id중복
	public int idcheck(String id);
	//email중복
	public int emailcheck(String email);
}
