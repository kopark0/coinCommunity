package com.coin.coin.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.coin.coin.entity.Member;
import com.coin.coin.mapper.JoinMapper;

public class JoinDaoImpl implements JoinDao {
	
	private final JoinMapper mapper;
	
	@Autowired
	public JoinDaoImpl(JoinMapper mapper) {
		this.mapper = mapper;
	}
	

	@Override
	public int memberupdate(Member member) {
		return mapper.memberupdate(member);
		
	}
	
//	private final JoinMapper mapper;
//	
//	@Autowired
//	public  JoinDaoImpl(JoinMapper mapper) {
//		this.mapper = mapper;
//	}
//
//	@Override
//	public void memberJoin(Member member) {
//		return mapper.memberJoin(member);
//	}
	
	

}
