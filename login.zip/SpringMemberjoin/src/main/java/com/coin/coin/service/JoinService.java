package com.coin.coin.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coin.coin.dao.JoinDao;
import com.coin.coin.entity.Member;
import com.coin.coin.mapper.JoinMapper;

@Service
public class JoinService {
	
	@Autowired
	JoinMapper mapper;
	
	
	public void memberJoin(Member member) {
		mapper.memberJoin(member);
	}
	
	public Member findId(String email) {
		return mapper.findId(email);
	}
	
	public Member memberlogin(Member member) {
		return mapper.memberlogin(member);
	}

	public Member findall(String id){
		return mapper.selectall(id);
	}
	
	public String memberupdate(Member member) {
		
		int cnt = mapper.memberupdate(member);
		
		if(cnt == 1) {
			return "수정성공";
		}else {
			return "수정실패";
		}
	}
	
	public int deletemember(String id, String password) {
		return mapper.memberdelete(id, password);
		
	}
	
	//idchk
	public int idcheck(String id) {
		int result = mapper.idcheck(id);
		return result;
	}

	//emailchk
	public int emailcheck(String email) {
		int result = mapper.emailcheck(email);
		return result;
	}
}
